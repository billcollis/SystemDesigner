License:
This software is free for schools and individuals to use.

Please send all ideas and bug reports to Bill Collis email:techideasnz@gmail.com

I am especially grateful to:
Mindfusion.eu for their generous support,
Being able to use AvalonDock and FastColouredTextBox,
Jack Crenshaw for his article on compiler writing.

To get you started:
- There are a few simple examples files in the folder 
- There is lots of stuff in the help file
- There are instructions in my textbook, "An Introduction to Practical Electronics, Microcontrollers and Software Design"
- There may also be a couple of youtube videos, search billcollis systemdesigner

Version info
0.7.2 - add TXD,change mem model to reflect stack operations and added view of stackptr for the line number, changed folder naming, changed timer 1&2 to used output compare, fixed a pin register issue not updated between viz runs, fixed XML file to get 2 interrupts working, renamed scope vars
0.7.1 - fixed post incr/dec, added ADCL/H in registers, >>= <<=, fixed StateDiag Exit action, changed zoom in BD, changed C to use ADC in single mode not free running, loads XTAL values from Micro XML file
0.7.0 - changed language choice selection to checked buttons on the toolbar, various fixes
0.6.14 - work on Timer code as part of State machine, add pullup resistor activations to BASIC binary configs, modified ADC autocode, and removed statemachine analog code hints
0.6.13 - fixed BoardLayout diagram saving and loading issue, visualiser removed saving lastview, added statemachine code hints
0.6.12 - implmented oscilloscope in visualiser, fixed config clock in Basic
0.6.11 - fixed endless loop in Basic Parser
0.6.10 - fixed some LCD commands in Basic Parser
0.6.8 - flowchart live code window

0.6.0 visualiser for C and BASIC functioning well enough to start using with students
0.5.0 visualiser development, 	new diagrams: class diagram, sequence diagram
0.4.5 Stand alone visualisations developed: LED simulator, LED outputs, Seven Segment Display. FET switching, overflow, undeflow, binary numbers, ram simulator, string simulator,voltage dibider, LDR. ADC, Voltmeter, Variable PSU, Timers, PWM
0.4.0 diagramming tools implmented:block diagram, statemachine, mindmap, timeline, flowchart, system context, board layout, algorithm
