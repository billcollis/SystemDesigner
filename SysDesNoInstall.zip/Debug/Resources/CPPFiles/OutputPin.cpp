/*	Out.cpp
*	definition of class that handles output pins
*/

#include "OutputPin.h"

//first constructor
OutputPin::OutputPin(char avrRegister, char port, bool startHigh) :
IOPin(avrRegister,port)
{
	if(isValid()){
		// Set as output pin
		setAsOutput();

		// set initial state
		set(startHigh);
	}
}

//second constructor
OutputPin::OutputPin(char avrRegister, char port) :
IOPin(avrRegister,port)
{
	if(isValid()){
		// Set as output pin
		setAsOutput();

		// set initial state
		set(0);
	}
}


void OutputPin::set(bool high){
	if(isValid()){
		if (high)
			activatePullup();
		else
			deActivatePullup();
	}
};


void OutputPin::setHigh(){
	set(true);
}

void OutputPin::setLow() {
	set(false);
}

void OutputPin::toggle() {
	if(isValid()){
		if (isHigh())
		{
			setLow();
		} 
		else
		{
			setHigh();
		}
		//*avrPort ^= avrBit;
	}
}





