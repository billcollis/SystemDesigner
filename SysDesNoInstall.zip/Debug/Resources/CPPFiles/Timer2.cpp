/*	Timer2.cpp
*
*   Uses Timer2 to generate ticks every 1ms
*
*/

#include <avr/interrupt.h>
#include "Timer2.h"
#include "Util.h"

/* this counts the number of milliseconds since Timer/Counter 2
   was initialized (volatile to make sure loops work!) */
static volatile uint32_t s_msTimer = 0;


static TIMER2 timer;

TIMER2* TIMER2::get(){
	return &timer;
}

TIMER2::TIMER2()
{
	Init();
}


/* returns number of ms since Timer initialized */
uint32_t TIMER2::MsCur() const
{
	uint32_t ms;

	/* disable (delay) interrupts while we read
	   s_msTimer since it's 4 bytes and we don't
	   want it changing during the read! */
	CRITICAL_SECTION_START;
	ms = s_msTimer;
	CRITICAL_SECTION_END;

	return ms;
}

/* returns true if the specified number of milliseconds
   has passed since the start time */
bool TIMER2::HasElapsed(uint32_t msStart, unsigned int msWait) const
{
	return MsCur() - msStart > msWait;
}

/* waits (pauses) for the specified number of milliseconds */
void TIMER2::WaitMs(unsigned int ms) const
{
	WaitMs(ms, MsCur());
}

/* waits (pauses) for the specified number of milliseconds */
void TIMER2::WaitMs(unsigned int ms, uint32_t msStart) const
{
	while (!HasElapsed(msStart, ms))
		;
}

/* this interrupt happens every ms, when TCNT2 reaches OCR2 */
ISR(TIMER_VECTOR)
{
	++s_msTimer;
	//SCHEDULER::get()->runjobs();
}
