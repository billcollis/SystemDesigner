/*	Util.h
*
*	some useful utilities.
*
*/

#pragma once
#ifndef MYUTILS_DEFINED
#define MYUTILS_DEFINED

#define F_CPU  1000000UL

#ifndef cbi
#define cbi(avrRegister,bit)	avrRegister &= ~(BV(bit))
#endif
#ifndef sbi
#define sbi(avrRegister,bit)	avrRegister |= (BV(bit))
#endif
#ifndef cli
#define cli()			__asm__ __volatile__ ("cli" ::)
#endif
#ifndef sei
#define sei()			__asm__ __volatile__ ("sei" ::)
#endif
#ifndef BV
	#define BV(bit)			(1<<(bit))
#endif


#define _delay_2cycles()   __asm__ __volatile__( "rjmp 1f\n 1:" );

/*************************************************************************
 delay loop for small accurate delays: 16-bit counter, 4 cycles/loop 
 from PFleury LCD library
*************************************************************************/
static inline void _delayFourCycles(unsigned int __count)
{
    if ( __count == 0 )    
        __asm__ __volatile__( "rjmp 1f\n 1:" );    // 2 cycles
    else
        __asm__ __volatile__ (
    	    "1: sbiw %0,1" "\n\t"                  
    	    "brne 1b"                              // 4 cycles/loop
    	    : "=w" (__count)
    	    : "0" (__count)
    	   );
}
#define delay_us(us)  _delayFourCycles( ( ( 1*(F_CPU/4000) )*us)/1000 )

static inline void delay_ms(unsigned int __count)
{
	uint16_t __loopy;
	for (__loopy=0; __loopy<__count;__loopy++)
	{
		delay_us(1000);
	}
}
#endif


/*

extern "C" int clamp(int value, int minVal, int maxVal);

*/
#ifndef CRITICAL_SECTION_START
#define CRITICAL_SECTION_START	uint8_t _sreg = SREG; cli()
#define CRITICAL_SECTION_END	SREG = _sreg
#endif

