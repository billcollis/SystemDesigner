/*	In.h
*	definition of class that handles input pins
*/
#pragma once
#ifndef INPUT_PIN_DEFINED
#define INPUT_PIN_DEFINED

#include <avr/io.h>
#include "IOPin.h"

class InputPin : public IOPin
{
public:
	//constructor
	InputPin(char avrRegister, char pin, bool pullup);
};

#endif //INPUT_PIN_DEFINED


