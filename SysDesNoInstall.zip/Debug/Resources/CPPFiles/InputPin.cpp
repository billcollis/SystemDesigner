/*	Input.cpp
*	definition of class that handles input pins
*/

#include <avr/io.h>
#include "InputPin.h"


InputPin::InputPin(char avrRegister, char pin, bool pullup) :
	IOPin(avrRegister,pin)
{
	if(isValid()){
		// Set as input pin
		setAsInput();

		if (pullup)
			activatePullup();
		else
			deActivatePullup();
	}
}








