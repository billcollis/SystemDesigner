/*
	definition of class that controls pin as an Led
*/

#pragma once
#ifndef LEDOUTPUT_DEFINED
#define LEDOUTPUT_DEFINED

#include "OutputPin.h"

class Led : public OutputPin{

public:
	Led(char avrRegister, char pin);

	inline void On() {setHigh();}
	inline void Off() { setLow(); }
private:	
	Led() {} 						//private default constructor
};

#endif