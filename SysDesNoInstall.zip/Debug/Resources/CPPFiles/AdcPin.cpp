/*	AdcPin.cpp
	Analog Input using Analog to Digital Converter (ADC).
*/

#include <avr/io.h>
#include "AdcPin.h"
#include "Util.h"

bool AdcPin::initialised = false;

AdcPin::AdcPin(char avrRegister, char pin, char channel) :
	InputPin(avrRegister,pin,0)
{
	if (!initialised)			//only initialize on first instantiation of the ADC
		InitialiseADC();
	adc_channel=channel;
}

void AdcPin::InitialiseADC(ADC_PRESCALE prescale, ADC_REF reference)
{
	initialised = true;				//flag to remember that it has been initialised already
	
	ADMUX &= 0x3F;					//clear the two reference bits REFS1 REFS0
	ADMUX |= (reference << 6);		//move the two bits into REFS1 and REFS0
	ADCSRA &= 0xFE;					//clear the 3 prescale bits ADPS2,1,0
	ADCSRA |=prescale;				//set the prescale
	ADCSRA |= (1<<ADEN);            //Power up the ADC
	ADCSRA |= (1<<ADSC);            //Start converting - takes 25 ADC cycles for first conv after power up
	while (ADCSRA & (1<<ADSC)){}	//wait for finish
}


// turn off AdcPin converter
void AdcPin::TurnOff()
{		
	ADCSRA &= ~(1<<ADEN);	// disable ADC (turn off ADC power - good for low power modes)
	initialised = false;
}


// read the ADC value
uint16_t AdcPin::GetValue()
{
	ADMUX &= 0xF8;					//clear bottom 3 bits then add 3 channel bits
	ADMUX |= adc_channel;			//set the channel bits
	ADCSRA |= (1 << ADSC);			//start a conversion
	while (ADCSRA & (1<<ADSC));		//wait till its finished
	return ADC;						//return 10bit result
}

