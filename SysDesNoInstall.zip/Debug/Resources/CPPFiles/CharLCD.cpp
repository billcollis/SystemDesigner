﻿/*	CharLCD.cpp
*	definition of class that handles Character LCDs.
	note that RW pin is unused
*/

#include "CharLCD.h"

//constructor with initialiser list, see http://www.learncpp.com/cpp-tutorial/101-constructor-initialization-lists/
CharLCD::CharLCD(OutputPin* lcd_rs, OutputPin* lcd_en, OutputPin* lcd_dat4, OutputPin* lcd_dat5, OutputPin* lcd_dat6, OutputPin* lcd_dat7, char lcd_chars, char lcd_lines)
	: rs(lcd_rs),
	en(lcd_en),
	dat4(lcd_dat4),
	dat5(lcd_dat5),
	dat6(lcd_dat6),
	dat7(lcd_dat7),
	rows(lcd_chars),
	cols(lcd_lines)
{
}

	void CharLCD::init()
	{
		delay_us(20000);			//power up delay
		en->setLow();
		rw->setLow();
		rs->setLow();
		//Write D7-4 = 0011
		dat7->setLow();
		dat6->setLow();
		dat5->setHigh();
		dat4->setHigh();
		lcd_pulse_en();
		delay_us(1000);
		//repeat again
		lcd_pulse_en();
		delay_us(1000);
		//repeat again
		lcd_pulse_en();
		delay_us(1000);
		//Write D7-4 = 0010
		dat7->setLow();
		dat6->setLow();
		dat5->setHigh();
		dat4->setLow();
		lcd_pulse_en();
		delay_us(1000);
		
		command(0x28); //4bits, 2 lines, 5*7 pixels
		command(0x0E); //cursor on
		command(0x06); //
		command(0x01); //clear and home
		delay_us(4000);
		command(0x80); //set cursor position DDRAM address
		command(0x0C); //cursor off
	}
	void CharLCD::Off(){
		command(LCD_OFF);
	}
	void CharLCD::On(){
		command(LCD_ON);
	}
	void CharLCD::cursorOn()
	{
		command(LCD_ON_CURSOR);
	}
	void CharLCD::lcd_cursorOff()
	{
		command(LCD_ON);
	}
	void CharLCD::cursorBlink()
	{
		command(LCD_ON_BLINK);
	}
	void CharLCD::cls()
	{
		command(LCD_CLR);
	}
	void CharLCD::home()
	{
		command(LCD_HOME);
	}
	void CharLCD::cursorXY(char x, char y){				//0,0 is top left
		if (x>=rows || y>=cols ) {return;}		//ignore nonsense values
		if (y==0){command(LCD_X0Y0+x);}
		if (y==1){command(LCD_X0Y1+x);}
		if (y==2){command(LCD_X0Y2+x);}
		if (y==3){command(LCD_X0Y3+x);}
	}
	void CharLCD::line0(){
		command(LCD_X0Y0);
	}
	void CharLCD::line1(){
		command(LCD_X0Y1);
	}
	void CharLCD::line2(){
		command(LCD_X0Y2);
	}
	void CharLCD::line3(){
		command(LCD_X0Y3);
	}
	
	void CharLCD::disp(const char *str)	{		//text string
		register uint8_t c;
		while ((c=*str++)){
			delay_us(LCD_DELAY);
			lcd_data(c);
		}
	}
	
	void CharLCD::disp(signed char n)	{				//-127 to 127
		char buffer[3];
		itoa (n, buffer,4);						//decimal display
		disp(buffer);
	}
	void CharLCD::disp(uint8_t n)	{			//0 to 255
		char buffer[3];
		itoa (n, buffer,10);					//decimal display of
		disp(buffer);
	}
	void CharLCD::disp_bin(uint8_t n)	{		//0 to 255
		char buffer[8];
		itoa (n, buffer,2);					//binary display of
		disp(buffer);
	}
	void CharLCD::disp_bin(signed char n)	{		//0 to 255
		char buffer[8];
		itoa (n, buffer,2);						//binary display of
		disp(buffer);
	}

	void CharLCD::disp(unsigned int n)	{			//- to
		char buffer[7];
		itoa (n, buffer,10);				//decimal display
		disp(buffer);
	}
	void CharLCD::disp(signed int n)	{				//- to
		char buffer[7];
		itoa (n, buffer,10);				//decimal display
		disp(buffer);
	}
	void CharLCD::disp_bin(unsigned int n)	{		//- to
		char buffer[16];
		itoa (n, buffer,2);					//binary display
		disp(buffer);
	}
	void CharLCD::disp_bin(signed int n)	{			//- to
		char buffer[16];
		itoa (n, buffer,2);					//binary display
		disp(buffer);
	}

	void CharLCD::command(uint8_t dat)	{
		delay_us(LCD_DELAY);
		lcd_write(dat,0);
	}
	void CharLCD::lcd_data(uint8_t dat)	{
		delay_us(LCD_DELAY);
		lcd_write(dat,1);
	}


	/*		wait until LCD has finished processing - not used	*/
	void CharLCD::lcd_wait_busy()
	//uint8_t lcd_wait_busy()
	{
		//uint8_t address;
		//while((address=lcd_read(0)) & LCD_BUSY){}
		delay_us(LCD_DELAY);
		//delay_us(2);
		//return(lcd_read(0));
	}

	void CharLCD::lcd_write(uint8_t dat, char rs)	{
			if (rs){						//is it data or command
				rs->setHigh();				//data
			}else{
				rs->setLow();				//command
			}
			rw->setLow();					//outputs
			//get upper4 bits of dat and put onto the 4 pins
			//if (dat & 0x80) {_dat7->setHigh();}else{_dat7->setLow();}
			(dat & 0x80) ? dat7->setHigh() : dat7->setLow();
			if (dat & 0x40) {dat6->setHigh();}else{dat6->setLow();}
			if (dat & 0x20) {dat5->setHigh();}else{dat5->setLow();}
			if (dat & 0x10) {dat4->setHigh();}else{dat4->setLow();}
			lcd_pulse_en();
			
			if (dat & 0x08) {dat7->setHigh();}else{dat7->setLow();}
			if (dat & 0x04) {dat6->setHigh();}else{dat6->setLow();}
			if (dat & 0x02) {dat5->setHigh();}else{dat5->setLow();}
			if (dat & 0x01) {dat4->setHigh();}else{dat4->setLow();}
			lcd_pulse_en();
	}
/*	uint8_t CharLCD::lcd_read(uint8_t rs)
	{
			uint8_t dat;
			dat=0;
			if (rs){						//is it data or command
				rs->setHigh();				//data
			}else{
				rs->setLow();				//command
			}
			rw->setHigh();					//reading
			
			//set 4 pins as inputs
			dat7->SetAsInput();
			dat6->SetAsInput();
			dat5->SetAsInput();
			dat4->SetAsInput();
			
			//get 4 bits of dat and put into the upper nibble of dat
			en->setHigh();
			delay_2cycles();
			if (dat7->IsHigh()){dat|=0x80;}
			if (dat6->IsHigh()){dat|=0x40;}
			if (dat5->IsHigh()){dat|=0x20;}
			if (dat4->IsHigh()){dat|=0x10;}
			en->setLow();
			delay_2cycles();
				
			//get 4 bits of dat and put into the lower nibble of dat
			en->setHigh();
			delay_2cycles();
			if (dat7->IsHigh()){dat|=0x08;}
			if (dat6->IsHigh()){dat|=0x04;}
			if (dat5->IsHigh()){dat|=0x02;}
			if (dat4->IsHigh()){dat|=0x01;}
			en->setLow();
			delay_2cycles();
			
			return dat;
	}
	*/
	void CharLCD::lcd_pulse_en(){
		en->setHigh();
		delay_us(100);
		en->setLow();
	}

