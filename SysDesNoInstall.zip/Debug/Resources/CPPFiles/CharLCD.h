/*	CharLCD.h
*	definition of class that handles Character LCDs.
	note that he rw pin is unused
*/

#pragma once
#ifndef CharLCD_DEFINED
#define CharLCD_DEFINED

#include <avr/io.h>
#include <stdlib.h>
#include "OutputPin.h"
#include "IOPin.h"
#include "Util.h"

const int LCD_DELAY=200;


//LCD commands
#define LCD_CLR			0x01		// clear LCD
#define LCD_HOME		0x02		// clear LCD
// see animations http://www.geocities.com/dinceraydin/lcd/commands.htm for the following commands
#define LCD_SHIFTDEC			0x04		// decrement address counter, display shift off
#define LCD_DEC			0x05		// decrement address counter, display shift on 
#define LCD_INC			0x06		// Increment address counter, display shift off - default
#define LCD_SHIFTINC			0x07		// Increment address counter, display shift on

#define LCD_ALL			0x0F		// LCD On, LCD display on, cursor on and blink on
#define LCD_ON          0x0C		// turn lcd on/no cursor
#define LCD_OFF         0x08		// turn lcd off
#define LCD_ON_DISPLAY  0x04		// turn display on
#define LCD_ON_CURSOR   0x0E		// turn cursor on
#define LCD_ON_BLINK    0x0F		// cursor blink
#define LCD_X0Y0		0x80        // cursor Pos on line 1 (or with column)
#define LCD_X0Y1		0xC0        // cursor Pos on line 2 (or with column)
#define LCD_X0Y2		0x94        // cursor Pos on line 3 (or with column)
#define LCD_X0Y3		0xD4        // cursor Pos on line 4 (or with column)
#define LCD_CURSOR_LEFT 0x10		//move cursor one place to left
#define LCD_CURSOR_RIGHT 0x14		//move cursor one place to right

#define LCD_BUSY 0x80      /* DB7: LCD is busy- not used       */



class CharLCD 
{
public:
	/* constructor  */
	CharLCD(OutputPin* lcd_rs, OutputPin* lcd_en, OutputPin* lcd_dat4, OutputPin* lcd_dat5, OutputPin* lcd_dat6, OutputPin* lcd_dat7, char lcd_chars, char lcd_lines);

	void init();
	void Off();
	void On();
	void cursorOn();
	void lcd_cursorOff();
	void cursorBlink();
	void cls();
	void home();
	void cursorXY(char x, char y);
	void line0();
	void line1();
	void line2();
	void line3();
	void disp(const char *str);
	void disp(signed char n);
	void disp(uint8_t n);
	void disp_bin(uint8_t n);
	void disp_bin(signed char n);
	void disp(unsigned int n);
	void disp(signed int n);
	void disp_bin(unsigned int n);
	void disp_bin(signed int n);
	void command(uint8_t dat);
	void lcd_data(uint8_t dat);
	void lcd_wait_busy();/*		wait until LCD has finished processing - not used just a delay	*/
	void lcd_write(uint8_t dat, char rs);
	//uint8_t lcd_read(uint8_t rs);
	void lcd_pulse_en();

protected:
	uint8_t rows;
	uint8_t cols;
	OutputPin* rs;
	OutputPin* rw;
	OutputPin* en;
	OutputPin* dat4;
	OutputPin* dat5;
	OutputPin* dat6;
	OutputPin* dat7;
};

#endif
