/*	IOPin.h
*	definition for class that handles control of i/o pins
*/
#pragma once
#ifndef IOPIN_DEFINED
#define IOPIN_DEFINED

#include <avr/io.h>

class IOPin
{
public:
	// public constructor 
	IOPin(char avrRegister, char pin);
	
	inline uint8_t getBit() const {return avrBit;};
	inline bool isValid() const {return pinValid;};
	bool isHigh();
	bool isLow();

protected:
	void setAsInput();
	void setAsOutput();
	void activatePullup();
	void deActivatePullup();
	
private:	
	IOPIn() {} 						//private default constructor
	uint8_t				avrBit;		// The bit mask for this pin
	volatile uint8_t*	avrPort;	// The port register
	volatile uint8_t*	avrPin;		// The PIN register
	volatile uint8_t*	dataDirReg;	// The data direction register
	bool		pinValid;			// Does the constructor define a valid pin
};

#endif


