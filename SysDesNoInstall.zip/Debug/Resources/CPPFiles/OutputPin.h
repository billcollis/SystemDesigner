/*	Out.h
*	Definition of class that handles output pins.
*/

#pragma once
#ifndef OUTPUT_PIN_DEFINED
#define OUTPUT_PIN_DEFINED

#include <avr/io.h>
#include "IOPin.h"

class OutputPin : public IOPin {
public:
	/* constructors */
	OutputPin(char avrRegister, char port, bool startHigh);
	OutputPin(char avrRegister, char port);
	
	void set(bool high);	// set high if true, low if false
	void setHigh();
	void setLow();
	void toggle();

};

#endif //OutputPin
