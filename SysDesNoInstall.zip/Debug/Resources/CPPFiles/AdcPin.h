/*	AdcPin.cpp
  	ADC is in polled mode i.e. takes a reading only when asked for it 
	works for:
		ATMega64
		ATMega16A
		ATMega644
	still to check / modify for:
		ATTiny461 - has more ADC channels and 2 Int Ref 1.1V & 2.56V
		ATMega8 - note ADC6 and ADC7 do not have ports, also has 1.1V ref not 2.56
*/
#pragma once
#ifndef ADC_PIN_DEFINED
#define ADC_PIN_DEFINED

#include "InputPin.h"


// ADC prescaler select, adc freq should be 50khz to 200Khz
// at 20Mhz prescaler = 128 gives 156Khz
// at 8Mhz prescaler = 64 gives 125Khz
// at 1MHz prescaler = 8 gives 125KHz
typedef enum {
	ADC_PRE_DIV2 = 0x00,	///< 0x01,0x00 -> CPU clk/2
	ADC_PRE_DIV4 = 0x02,	///< 0x02 -> CPU clk/4
	ADC_PRE_DIV8 = 0x03,	///< 0x03 -> CPU clk/8
	ADC_PRE_DIV16 = 0x04,	///< 0x04 -> CPU clk/16
	ADC_PRE_DIV32 = 0x05,	///< 0x05 -> CPU clk/32
	ADC_PRE_DIV64 = 0x06,	///< 0x06 -> CPU clk/64
	ADC_PRE_DIV128 = 0x07	///< 0x07 -> CPU clk/128
} ADC_PRESCALE;

//Be aware that selecting a bad option here can cause a short on your hardware
// setting the internal or AVCC options actually makes the connection between 
// AVCC or internal ref voltage and the AREF pin
// so make sure AREF has no external power applied to it before you do this 
// or you get two voltage sources of different values shorted together

typedef enum {
	ADC_REF_AREF = 0x00,	// expects voltage on AREF pin    
	ADC_REF_AVCC = 0x01,	//uses AVCC as ref,
	ADC_REF_11V = 0x02,		//internal 1.1V ref (e.g. ATTiny461)
	ADC_REF_256V = 0x03		//internal 2.56V ref(e.g. ATTiny461, ATMega 16/644 on ATMEga8 this is 1.1V)
} ADC_REF;


#define ADC_REF_DEFAULT				ADC_REF_256V
#define ADC_PRESCALE_DEFAULT		ADC_PRE_DIV8



class AdcPin : public InputPin  //extends INput pin
{
public:
	/* constructor for setting Port and  channel (check the config for diff Tiny/Mega chips */
	AdcPin(char avrRegister, char pin, char channel);
 
	uint16_t GetValue();	//read the 10bit adc value

	//even though we can configure multiple ADC pins,
	//we only ever need to initialize the ADC once or turn if off once, so these are static
	static void InitialiseADC(ADC_PRESCALE=ADC_PRESCALE_DEFAULT, ADC_REF=ADC_REF_DEFAULT);
	static void TurnOff();

private:
	char adc_channel;
	static bool initialised; //having static var means one applies to every instance of the object
};
#endif
