
#include <avr/io.h>

#include "Led.h"

Led::Led(char avrRegister, char pin)
: OutputPin(avrRegister, pin, false) //inherits from OutputPin
{
	Off(); //constructor makes sure LED is off
}

