/*	IOPin.cpp
*	definition for class that handles control, reading and writing of i/o pins
*/
#include "IOPin.h"
#include <avr/io.h>

IOPin::IOPin(char avrRegister, char pin){
		avrBit = _BV(pin);			// Get the bit mask for this port
		pinValid = true;			//ASSUME THAT THIS DEFINITION IS TRUE
	
		
		switch (avrRegister)
		{
			case 'a':case 'A':
				dataDirReg = &DDRA;
				avrPin = &PINA;
				avrPort = &PORTA;
				break;
			case 'b':case 'B':
				dataDirReg = &DDRB;
				avrPin = &PINB;
				avrPort = &PORTB;
				break;
		#if defined (__AVR_ATmega16A__) || defined (__AVR_ATmega644A__) || defined (_AVR_ATmega64A_) //add any micro definitions you need here
			case 'c':case 'C':
				dataDirReg = &DDRC;
				avrPin = &PINC;
				avrPort = &PORTC;
				break;
			case 'd':case 'D':
				dataDirReg = &DDRD;
				avrPin = &PIND;
				avrPort = &PORTD;
				break;
		#endif
		
	
		#if defined (_AVR_ATmega64A_)
			case 'e':case 'E':
				dataDirReg = &DDRE;
				avrPin = &PINE;
				avrPort = &PORTE;
				break;
			case 'f':case 'F':
				dataDirReg = &DDRF;
				avrPin = &PINF;
				avrPort = &PORTF;
				break;
			case 'g':case 'G':
				dataDirReg = &DDRG;
				avrPin = &PING;
				avrPort = &PORTG;
				break;
		#endif
			default:
				pinValid = false;
		}
	};

void IOPin::setAsInput(){
	if(pinValid){
		*dataDirReg &= ~avrBit;
	}
};

void IOPin::setAsOutput(){
	if(pinValid){
		*dataDirReg |= avrBit;	
	}
};

bool IOPin::isHigh() {
	return (isValid()) ? *avrPin & avrBit :false;
}

/* returns true if pin is reading low, else false */
bool IOPin::isLow()  {
	return !isHigh();
}

void IOPin::activatePullup(){
	*avrPort |= avrBit;		// enable pull-up resistor
	}
	
void IOPin::deActivatePullup(){
	*avrPort &= ~avrBit;	// disable pull-up resistors	
}