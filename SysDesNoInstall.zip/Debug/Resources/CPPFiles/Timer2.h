/*	Timer2.h
*
*	Accurate timing using Timer 2 to generate ticks every 1ms
*
*/

#pragma once
#ifndef TIMER2_DEFINED
#define TIMER2_DEFINED
#include "Util.h"

class TIMER2
{

public:

	/* Get the one and only timer instance */
	static TIMER2* get();

	/* returns number of ms since Timer initialized */
	uint32_t MsCur() const;

	/* returns true if the specified number of milliseconds
	   has passed since the start time (else returns false) */
	bool HasElapsed(uint32_t, unsigned int msWait) const;

	/* pauses (waits) for the specified number of milliseconds */
	void WaitMs(unsigned int ms) const;

	/* pauses (waits) for the specified number of milliseconds 
	   from the given start time
	*/
	void WaitMs(unsigned int ms, uint32_t msStart) const;

	/* constructor for initializing Timer/Counter 2 for timing */
	TIMER2();
	
private:

	static void Init(){

	/* start counting at 0 */
	TCNT2 = 0;


#if F_CPU == 32000000
	/* CS (Clock Select) /256 [110] -- 32 Mhz / 256 = 125kHz 
	   CTC (Clear Timer on Compare Match) waveform generation mode [10]
	   OCR2 (top/clear value) = 125
	   for match every 1 ms
	*/
	TCCR2 = 0x0e;	// 0 0 00 1 110
	OCR2 = 125;
	sbi(TIMSK, OCIE2);
	#define TIMER_VECTOR TIMER2_COMP_vect
#elif F_CPU == 20000000
	/* CS (Clock Select) /128 [101] -- 20 Mhz / 128 = 156.25kHz 
	   CTC (Clear Timer on Compare Match) waveform generation mode [10]
	   OCR2 (top/clear value) = 156
	   for match every 1 ms (approx)
	*/
	#ifdef TCCR2A
		sbi(TCCR2A,WGM21);	// Set
		cbi(TCCR2A,WGM20);	//  CTC
		cbi(TCCR2B,WGM22);  //    Mode
		sbi(TCCR2B,CS22);	// div by 128
		cbi(TCCR2B,CS21);	// div by 128
		sbi(TCCR2B,CS20);	// div by 128
		OCR2A = 156;
		sbi(TIMSK2, OCIE2A);
		#define TIMER_VECTOR TIMER2_COMPA_vect
	#else
		TCCR2 = 0x0d;	// 0 0 00 1 101
		OCR2 = 156;
		sbi(TIMSK, OCIE2);
		#define TIMER_VECTOR TIMER2_COMP_vect
	#endif
#elif F_CPU == 16000000
	/* CS (Clock Select) /128 [101] -- 16 Mhz / 128 = 125kHz 
	   CTC (Clear Timer on Compare Match) waveform generation mode [10]
	   OCR2 (top/clear value) = 125
	   for match every 1 ms
	*/
	TCCR2 = 0x0d;	// 0 0 00 1 101
	OCR2 = 125;
	sbi(TIMSK, OCIE2);
	#define TIMER_VECTOR TIMER2_COMP_vect
#elif F_CPU == 8000000
	/* CS (Clock Select) /64 [100] -- 8 Mhz / 64 = 125kHz 
	   CTC (Clear Timer on Compare Match) waveform generation mode [10]
	   OCR2 (top/clear value) = 125
	   for match every 1 ms
	*/
	#ifdef TCCR2A
		sbi(TCCR2A,WGM21);	// Set
		cbi(TCCR2A,WGM20);	//  CTC
		cbi(TCCR2B,WGM22);  //    Mode
		sbi(TCCR2B,CS22);	// div by 64
		cbi(TCCR2B,CS21);	// div by 64
		cbi(TCCR2B,CS20);	// div by 64
		OCR2A = 125;
		sbi(TIMSK2, OCIE2A);
		#define TIMER_VECTOR TIMER2_COMPA_vect
	#else
		TCCR2 = 0x0c;	//	 0 0 00 1 100
		OCR2 = 125;
		sbi(TIMSK, OCIE2);
		#define TIMER_VECTOR TIMER2_COMP_vect
	#endif
#elif F_CPU == 1000000
	/* CS (Clock Select) /8 [010] -- 1 Mhz / 8 = 125kHz 
	   CTC (Clear Timer on Compare Match) waveform generation mode [10]
	   OCR2 (top/clear value) = 125
	   for match every 1 ms
	*/
	TCCR2 = 0x0a;	// 0 0 00 1 010
	OCR2 = 125;
	sbi(TIMSK, OCIE2);
	#define TIMER_VECTOR TIMER2_COMP_vect
#else
#error	No F_CPU has been set or it is an unrecognised value
#endif

	
	/* set I-bit in SREG (global enable for interrupts) */
	sei();
	}
	
};
#endif
