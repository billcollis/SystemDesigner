/*	CharLCD.h
*	Declarations for char LCD functions
*/

#pragma once
#ifndef CharLCD_H
#define CharLCD_H

#include <stdlib.h> //itoa

//LCD commands
#define LCD_CLR			0x01		// clear LCD
#define LCD_HOME		0x02		// clear LCD
// see animations http://www.geocities.com/dinceraydin/lcd/commands.htm for the following commands
#define LCD_DEC			0x04		// decrement address counter, display shift off
#define LCD_DEC_SHIFT	0x05		// decrement address counter, display shift on 
#define LCD_INC			0x06		// Increment address counter, display shift off - default
#define LCD_INC_SHIFT	0x07		// Increment address counter, display shift on

#define LCD_ALL			0x0F		// LCD On, LCD display on, cursor on and blink on
#define LCD_ON          0x0C		// turn lcd on/no cursor
#define LCD_OFF         0x08		// turn lcd off
#define LCD_ON_DISPLAY  0x04		// turn display on
#define LCD_ON_CURSOR   0x0E		// turn cursor on
#define LCD_ON_BLINK    0x0F		// cursor blink
#define LCD_X0Y0		0x80        // cursor Pos on glcd_line 1 (or with column)
#define LCD_X0Y1		0xC0        // cursor Pos on glcd_line 2 (or with column)
#define LCD_X0Y2		0x94        // cursor Pos on glcd_line 3 (or with column)
#define LCD_X0Y3		0xD4        // cursor Pos on glcd_line 4 (or with column)
#define LCD_CURSOR_LEFT 0x10		//move cursor one place to left
#define LCD_CURSOR_RIGHT 0x14		//move cursor one place to right

#define LCD_DELAY       100


#define lcd_en_high()    LCD_PORT_EN  |=  _BV(LCD_PIN_EN)
#define lcd_en_low()     LCD_PORT_EN  &= ~_BV(LCD_PIN_EN)

#define lcd_rs_high()   LCD_PORT_RS |= _BV(LCD_PIN_RS)
#define lcd_rs_low()    LCD_PORT_RS &= ~_BV(LCD_PIN_RS)

#define lcd_dat4_high()   LCD_PORT_DAT4 |=  _BV(LCD_PIN_DAT4)
#define lcd_dat4_low()    LCD_PORT_DAT4 &= ~_BV(LCD_PIN_DAT4)

#define lcd_dat5_high()   LCD_PORT_DAT5 |=  _BV(LCD_PIN_DAT5)
#define lcd_dat5_low()    LCD_PORT_DAT5 &= ~_BV(LCD_PIN_DAT5)

#define lcd_dat6_high()   LCD_PORT_DAT6 |=  _BV(LCD_PIN_DAT6)
#define lcd_dat6_low()    LCD_PORT_DAT6 &= ~_BV(LCD_PIN_DAT6)

#define lcd_dat7_high()   LCD_PORT_DAT7 |=  _BV(LCD_PIN_DAT7)
#define lcd_dat7_low()    LCD_PORT_DAT7 &= ~_BV(LCD_PIN_DAT7)

void lcd_write(unsigned char dat, char rs);
void lcd_pulse_en();
void lcd_init();
void lcd_off();
void lcd_on();
void lcd_cursorOn();
void lcd_cursorOff();
void lcd_cursorBlink();
void lcd_cls();
void lcd_home();
void lcd_cursorXY(char x, char y);
void lcd_line0();
void lcd_line1();
void lcd_line2();
void lcd_line3();
void lcd_disp_str(const char *str);
void lcd_disp_str2(const char *str); //temp
void lcd_disp_str_P(const char *str);
void lcd_disp_dec_uchar(unsigned char n);
void lcd_disp_bin_uchar(unsigned char n);
void lcd_disp_bin_schar(signed char n);
void lcd_disp_dec_uint(unsigned int n);
void lcd_dispdec_sint(signed int n);
void lcd_disp_bin_unit(unsigned int n);
void lcd_disp_bin_sint(signed int n);
void lcd_command(unsigned char dat);
void lcd_data(unsigned char dat);

static inline void _delayFourCycles(unsigned int __count)
{
    if ( __count == 0 )
    __asm__ __volatile__( "rjmp 1f\n 1:" );    // 2 cycles
    else
    __asm__ __volatile__ (
    "1: sbiw %0,1" "\n\t"
    "brne 1b"                              // 4 cycles/loop
    : "=w" (__count)
    : "0" (__count)
    );
}

#define delay_us(us)  _delayFourCycles( ( ( 1*(F_CPU/4000) )*us)/1000 )

// address of data direction register of port, this is 1 less than the PORT address
#define DDR(port) (*(&port - 1))  

void lcd_init()
{
    //setup 6 pins as outputs
    DDR(LCD_PORT_RS) |= _BV(LCD_PIN_RS);
    DDR(LCD_PORT_EN) |= _BV(LCD_PIN_EN);
    DDR(LCD_PORT_DAT7) |= _BV(LCD_PIN_DAT7);
    DDR(LCD_PORT_DAT6) |= _BV(LCD_PIN_DAT6);
    DDR(LCD_PORT_DAT5) |= _BV(LCD_PIN_DAT5);
    DDR(LCD_PORT_DAT4) |= _BV(LCD_PIN_DAT4);
    
    lcd_en_high();
    delay_us(20000);            //power up delay 
    lcd_en_low();
    lcd_rs_low();
    //Write D7-4 = 0011
    lcd_dat7_low();
    lcd_dat6_low();
    lcd_dat5_high();
    lcd_dat4_high();
    lcd_pulse_en();
    delay_us(5000);
    //repeat again
    lcd_pulse_en();
    delay_us(200);
    //repeat again
    lcd_pulse_en();
    delay_us(200);
    //Write D7-4 = 0010
    lcd_dat7_low();
    lcd_dat6_low();
    lcd_dat5_high();
    lcd_dat4_low();
    lcd_pulse_en();
    delay_us(1000);
        
    lcd_command(0x28);  //0b0010100 is interface=4bits, 2 lines, 5*7 pixels
    lcd_command(0x06);  //move cursor right after each write to the display
    lcd_command(0x01);  //clear and home lcd
    delay_us(4000);     //give display a chance to do the above
    lcd_command(0x0C);  //display on ,cursor off, no blink
}

void lcd_write(unsigned char dat, char rs)  
{
    if (rs ) {lcd_rs_high();} else {lcd_rs_low();}  //command=1 or data=0
    //get upper4 bits of dat and put onto the 4 pins
    if (dat & 0x80) {lcd_dat7_high();}else{lcd_dat7_low();}
    if (dat & 0x40) {lcd_dat6_high();}else{lcd_dat6_low();}
    if (dat & 0x20) {lcd_dat5_high();}else{lcd_dat5_low();}
    if (dat & 0x10) {lcd_dat4_high();}else{lcd_dat4_low();}
    lcd_pulse_en();
    //get lower4 bits of dat and put onto the 4 pins        
    if (dat & 0x08) {lcd_dat7_high();}else{lcd_dat7_low();}
    if (dat & 0x04) {lcd_dat6_high();}else{lcd_dat6_low();}
    if (dat & 0x02) {lcd_dat5_high();}else{lcd_dat5_low();}
    if (dat & 0x01) {lcd_dat4_high();}else{lcd_dat4_low();}
    lcd_pulse_en();
}

void lcd_pulse_en()
{
    lcd_en_high();
    delay_us(100);
    lcd_en_low();
}
void lcd_off()          {lcd_command(LCD_OFF);}
void lcd_on()           {lcd_command(LCD_ON);}
void lcd_cursorOn()     {lcd_command(LCD_ON_CURSOR);}//no blink
void lcd_cursorOff()    {lcd_command(LCD_ON);}
void lcd_cursorBlink()  {lcd_command(LCD_ON_BLINK);}
void lcd_cls()          {lcd_command(LCD_CLR);}
void lcd_home()         {lcd_command(LCD_HOME);}
void lcd_line0()        {lcd_command(LCD_X0Y0);}
void lcd_line1()        {lcd_command(LCD_X0Y1);}
void lcd_line2()        {lcd_command(LCD_X0Y2);}
void lcd_line3()        {lcd_command(LCD_X0Y3);}

void lcd_cursorXY(char x, char y){              //0,0 is top left
    if (y>=LCD_DISP_LINES || x>=LCD_DISP_LENGTH ) {return;}     //ignore nonsense values
    if (y==0){lcd_command(LCD_X0Y0+x);}         //0x80+ x value
    if (y==1){lcd_command(LCD_X0Y1+x);}
    if (y==2){lcd_command(LCD_X0Y2+x);}
    if (y==3){lcd_command(LCD_X0Y3+x);}
}
    

void lcd_disp_str2(const char *str) {       //text string
    register unsigned char c;
    while ((c=*str++)){                 //get contents of str then incr str
        delay_us(LCD_DELAY);
        lcd_data(c);
    }
}
void lcd_disp_str(const char *str)  {       //text string
    register unsigned char i;
    for (i=0; str[i];i++) //loop till null termination
    {
        delay_us(LCD_DELAY);
        lcd_data(str[i]);
    }
}

void lcd_disp_str_P(const char *str)    {       //text string
    register unsigned char i;
    for (i=0; (char)pgm_read_byte(&str[i]);i++) //loop till null termination
    {
        delay_us(LCD_DELAY);
        lcd_data((char)pgm_read_byte(&str[i]));
    }
}

   
void lcd_disp_dec_uchar(unsigned char n)    {           //0 to 255
    char buffer[3];
    itoa (n, buffer,10);                    //decimal display of
    lcd_disp_str(buffer);
}
void lcd_disp_bin_uchar(unsigned char n)    {       //0 to 255
    char buffer[8];
    itoa (n, buffer,2);                 //binary display of
    lcd_disp_str(buffer);
}
void lcd_disp_bin_schar(signed char n)  {       //0 to 255
    char buffer[8];
    itoa (n, buffer,2);                     //binary display of
    lcd_disp_str(buffer);
}

void lcd_disp_dec_uint(unsigned int n)  {           //- to
    char buffer[7];
    itoa (n, buffer,10);                //decimal display
    lcd_disp_str(buffer);
}
void lcd_dispdec_sint(signed int n) {               //- to
    char buffer[7];
    itoa (n, buffer,10);                //decimal display
    lcd_disp_str(buffer);
}
void lcd_disp_bin_unit(unsigned int n)  {       //- to
    char buffer[16];
    itoa (n, buffer,2);                 //binary display
    lcd_disp_str(buffer);
}
void lcd_disp_bin_sint(signed int n)    {           //- to
    char buffer[16];
    itoa (n, buffer,2);                 //binary display
    lcd_disp_str(buffer);
}

void lcd_command(unsigned char dat) {
    delay_us(LCD_DELAY);
    lcd_write(dat,0);
}
void lcd_data(unsigned char dat)    {
    delay_us(LCD_DELAY);
    lcd_write(dat,1);
}



#endif //CharLCD_h
